﻿using HotelManagementSystem.data;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.DTOs
{
    [AutoMap(typeof(Invoice), ReverseMap = true)]

    public class InvoiceDTO
    {
        public int Id { get; set; }
        public int Duration { get; set; }
        public double TotalAmount { get; set; }
        [StringLength(500)]
        public string Notes { get; set; }
        public int GuestId { get; set; }
        public int BookingId { get; set; }
        public GuestDTO? Guest { get; set; }
        public BookingDTO? Booking { get; set; }
    }
}
