﻿namespace HotelManagementSystem.DTOs
{
    public class UserToRoleDTO
    {
        public string UserId { get; set; }
        public string RoleName { get; set; }
    }
}
