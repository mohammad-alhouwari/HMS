﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.DTOs
{
    public class SearchBookingDTO
    {
        public string? RoomNumber { get; set; }
        public string? GuestName { get; set; }
        public string? GuestPassportNumberOrId { get; set; }
        public DateTime? CheckInDate { get; set; }
        public DateTime? CheckOutDate { get; set; }
    }
}
