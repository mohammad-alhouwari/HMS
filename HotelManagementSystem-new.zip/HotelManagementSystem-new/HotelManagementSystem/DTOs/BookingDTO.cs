﻿using HotelManagementSystem.data;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using AutoMapper;

namespace HotelManagementSystem.DTOs
{
    [AutoMap(typeof(Booking),ReverseMap = true)]
    public class BookingDTO
    {
        public int Id { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }
        public DateTime? ActualCheckInDate { get; set; }
        public DateTime? ActualCheckOutDate { get; set; }
        public int GuestId { get; set; }
        public int RoomId { get; set; }
        public bool? IsPayed { get; set; }

        public GuestDTO? Guest { get; set; }
        public RoomDTO? Room { get; set; }
    }
}
