﻿using AutoMapper;
using HotelManagementSystem.data;

namespace HotelManagementSystem.DTOs
{
    [AutoMap(typeof(Room), ReverseMap = true)]

    public class RoomDTO
    {
        public int Id { get; set; }
        public string RoomNumber { get; set; }
        public int Capacity { get; set; }
        public double Price { get; set; }
        public string RoomStatus { get; set; }
        public string RoomType { get; set; }
    }
}
