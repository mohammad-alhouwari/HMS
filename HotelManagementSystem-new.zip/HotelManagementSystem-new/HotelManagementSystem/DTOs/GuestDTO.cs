﻿using HotelManagementSystem.data;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using AutoMapper;

namespace HotelManagementSystem.DTOs
{
    [AutoMap(typeof(Guest), ReverseMap = true)]

    public class GuestDTO
    {
        public int Id { get; set; }
        [StringLength(10)]
        public string PassportNumberOrId { get; set; }
        [StringLength(50)]
        public string FirstName { get; set; }
        [StringLength(50)]
        public string LastName { get; set; }
        [StringLength(50)]
        [EmailAddress]
        public string Email { get; set; }
        [StringLength(14)]
        public string Phone { get; set; }
    }
}
