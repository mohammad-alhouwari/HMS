﻿namespace HotelManagementSystem.DTOs
{
    public class SearchRoomDTO
    {
        public string? RoomNumber { get; set; }
        public int? Capacity { get; set; }
        public double? MinimumPrice { get; set; }
        public double? MaximumPrice { get; set; }
        public string? RoomStatus { get; set; }
        public string? RoomType { get; set; }
    }
}
