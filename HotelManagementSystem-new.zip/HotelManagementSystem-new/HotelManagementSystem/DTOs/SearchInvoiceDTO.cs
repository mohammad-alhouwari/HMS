﻿namespace HotelManagementSystem.DTOs
{
    public class SearchInvoiceDTO
    {
        public int? InvoiceId { get; set; }
        public int? Duration { get; set; }
        public double? MinimumAmount { get; set; }
        public double? MaximumAmount { get; set; }
        public string? GuestName { get; set; }
        public string? RoomNumber { get; set; }
    }
}
