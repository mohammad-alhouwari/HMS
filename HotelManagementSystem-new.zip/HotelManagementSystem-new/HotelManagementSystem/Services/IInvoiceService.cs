﻿using HotelManagementSystem.DTOs;

namespace HotelManagementSystem.Services
{
    public interface IInvoiceService
    {
        Task Add(InvoiceDTO InvoiceDTO);
        Task Delete(int id);
        Task<InvoiceDTO> Load(int id);
        Task<List<InvoiceDTO>> LoadAll(SearchInvoiceDTO search);
        Task Update(InvoiceDTO InvoiceDTO);
    }
}