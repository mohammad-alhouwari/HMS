﻿using HotelManagementSystem.DTOs;

namespace HotelManagementSystem.Services
{
    public interface IGuestService
    {
        Task Add(GuestDTO GuestDTO);
        Task Delete(int id);
        Task<GuestDTO> Load(int id);
        Task<List<GuestDTO>> LoadAll();
        Task Update(GuestDTO GuestDTO);
        Task<List<GuestDTO>> LoadAllWithUnpaidBooking();
    }
}