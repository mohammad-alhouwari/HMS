﻿using HotelManagementSystem.DTOs;
using HotelManagementSystem.Enums;

namespace HotelManagementSystem.Services
{
    public interface IRoomService
    {
        Task Add(RoomDTO RoomDTO);
        Task Delete(int id);
        Task<RoomDTO> Load(int id);
        Task<List<RoomDTO>> LoadAll(SearchRoomDTO? search);
        Task<List<RoomDTO>> LoadAllAvailable();
        Task<List<RoomDTO>> LoadAllAvailableRoomsForBooking(DateTime checkInDate, DateTime checkOutDate, int? currentRoomId = null);
        Task Update(RoomDTO RoomDTO);

        Task CheckInRoom(int id);
        Task CheckOutRoom(int id);
        List<string> GetRoomTypes();

        Task<List<object>> GetAllRoomBookingsInMonth(DateTime date, int currentRoomId);
    }
}