﻿using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HotelManagementSystem.Services
{
    public class RoleService : IRoleService
    {
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly UserManager<ApplicationUser> userManager;

        public RoleService(RoleManager<IdentityRole> _roleManager, UserManager<ApplicationUser> _userManager)
        {
            roleManager = _roleManager;
            userManager = _userManager;
        }



        public async Task<RoleDTO> GetRoleById(string id)
        {
            var role = await roleManager.FindByIdAsync(id);
            RoleDTO roleDTO = new RoleDTO()
            {
                Id = role.Id,
                Name = role.Name
            };
            return roleDTO;
        }

        public async Task<List<RoleDTO>> GetAllRoles()
        {
            var roles = await roleManager.Roles.ToListAsync();
            List<RoleDTO> AllRolesDTO = new List<RoleDTO>();
            foreach (var role in roles)
            {
                AllRolesDTO.Add(new RoleDTO()
                {
                    Id = role.Id,
                    Name = role.Name
                });
            }
            return AllRolesDTO;
        }

        public async Task<List<UserDTO>> GetUsersInRole(string roleName)
        {
            var usersInRole = await userManager.GetUsersInRoleAsync(roleName);
            return usersInRole.Select(user => new UserDTO
            {
                Id = user.Id,
                UserName = user.UserName,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName
            }).ToList();
        }

        public async Task<bool> AddUserToRole(string userId, string roleName)
        {
            var user = await userManager.FindByIdAsync(userId);
            if (user == null || !await roleManager.RoleExistsAsync(roleName))
            {
                return false; 
            }
            var result = await userManager.AddToRoleAsync(user, roleName);
            return result.Succeeded;
        }

        public async Task<bool> RemoveUserFromRole(string userId, string roleName)
        {
            var user = await userManager.FindByIdAsync(userId);
            if (user == null || !await roleManager.RoleExistsAsync(roleName))
            {
                return false; 
            }
            var result = await userManager.RemoveFromRoleAsync(user, roleName);
            return result.Succeeded;
        }

        public async Task<List<UserDTO>> GetUsersNotInRole(string roleName)
        {
            var allUsers = await userManager.Users.ToListAsync();
            var usersInRole = await userManager.GetUsersInRoleAsync(roleName);

            var usersNotInRole = allUsers
                .Where(user => !usersInRole.Any(u => u.Id == user.Id))
                .Select(user => new UserDTO
                {
                    Id = user.Id,
                    UserName = user.UserName,
                    Email = user.Email,
                    FirstName = user.FirstName,
                    LastName = user.LastName
                })
                .ToList();

            return usersNotInRole;
        }


    }
}
