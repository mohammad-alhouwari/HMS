﻿using HotelManagementSystem.DTOs;
using Microsoft.AspNetCore.Identity;

namespace HotelManagementSystem.Services
{
    public interface IRoleService
    {
        Task<RoleDTO> GetRoleById(string id);
        Task<List<RoleDTO>> GetAllRoles();
        Task<List<UserDTO>> GetUsersInRole(string roleName);
        Task<bool> AddUserToRole(string userId, string roleName);
        Task<bool> RemoveUserFromRole(string userId, string roleName);
        Task<List<UserDTO>> GetUsersNotInRole(string roleName);

    }
}