﻿using AutoMapper;
using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using HotelManagementSystem.Enums;
using HotelManagementSystem.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Linq;

namespace HotelManagementSystem.Services
{
    public class RoomService : IRoomService
    {
        private readonly IMapper mapper;
        private readonly IGeneric<Room> generic;
        private readonly HMSContext context;

        public RoomService(IMapper _mapper, IGeneric<Room> _generic,HMSContext _context)
        {
            mapper = _mapper;
            generic = _generic;
            context = _context;
        }

        public async Task Add(RoomDTO roomDTO)
        {
            roomDTO.RoomStatus = "Available";
            Room room = mapper.Map<Room>(roomDTO);
            await generic.Add(room);
        }
        public async Task Update(RoomDTO roomDTO)
        {
            Room room = mapper.Map<Room>(roomDTO);
            await generic.Update(room);
        }
        public async Task Delete(int id)
        {
            await generic.Delete(id);
        }

        public List<string> GetRoomTypes()
        {
            var roomTypes = Enum.GetValues(typeof(RoomTypes)).Cast<RoomTypes>().Select(e => e.ToString()).ToList();
            return roomTypes;
        }
        public async Task<RoomDTO> Load(int id)
        {
            return mapper.Map<RoomDTO>(await generic.Load(id));
        }
        public async Task<List<RoomDTO>> LoadAll(SearchRoomDTO search)
        {
            IQueryable<Room> loadList = context.Rooms.AsQueryable();
            if (!string.IsNullOrEmpty(search.RoomNumber))
            {
                loadList = loadList.Where(r => r.RoomNumber.Contains(search.RoomNumber));
            }
            if (search.Capacity.HasValue)
            {
                loadList = loadList.Where(r => r.Capacity == search.Capacity);
            }
            if (search.MinimumPrice.HasValue)
            {
                loadList = loadList.Where(r => r.Price >= search.MinimumPrice);
            }
            if (search.MaximumPrice.HasValue)
            {
                loadList = loadList.Where(r => r.Price <= search.MaximumPrice);
            }
            if (!string.IsNullOrEmpty(search.RoomStatus))
            {
                loadList = loadList.Where(r => r.RoomStatus == search.RoomStatus);
            }
            if (!string.IsNullOrEmpty(search.RoomType))
            {
                loadList = loadList.Where(r => r.RoomType == search.RoomType);
            }
            List<Room> rooms = await loadList.ToListAsync();
            return mapper.Map<List<RoomDTO>>(rooms);
        }

        public async Task<List<RoomDTO>> LoadAllAvailable()
        {
            return mapper.Map<List<RoomDTO>>(await context.Rooms.Where(x=>x.RoomStatus== "Available").ToListAsync());
        }


        public async Task<List<RoomDTO>> LoadAllAvailableRoomsForBooking(DateTime checkInDate, DateTime checkOutDate, int? currentRoomId = null)
        {
            List<int> unavailableRoomIds = await context.Bookings
                .Where(b => b.CheckInDate < checkOutDate && b.CheckOutDate > checkInDate && b.RoomId != currentRoomId)
                .Select(b => b.RoomId)
                .Distinct()
                .ToListAsync();

            List<Room> availableRooms = await context.Rooms
                .Where(r => !unavailableRoomIds.Contains(r.Id) || r.Id == currentRoomId)
                .ToListAsync();

            return mapper.Map<List<RoomDTO>>(availableRooms);
        }


        public async Task CheckInRoom(int id)
        {
            Room room = await generic.Load(id);
            room.RoomStatus = "Occupied";
            await generic.Update(room);
        }

        public async Task CheckOutRoom(int id)
        {
            Room room = await generic.Load(id);
            room.RoomStatus = "Available";
            await generic.Update(room);
        }

        public async Task<List<object>> GetAllRoomBookingsInMonth(DateTime date, int currentRoomId)
        {
            DateTime firstDayOfMonth = new DateTime(date.Year, date.Month, 1);
            DateTime lastDayOfMonth = new DateTime(date.Year, date.Month, DateTime.DaysInMonth(date.Year, date.Month));
            if (currentRoomId != null)
            {
                List<Booking> bookings = await context.Bookings.Include(b=>b.Guest).Where(b => b.RoomId == currentRoomId && ((b.CheckInDate >= firstDayOfMonth) && (b.CheckOutDate >= firstDayOfMonth) && (b.CheckInDate <= lastDayOfMonth) && (b.CheckOutDate <= lastDayOfMonth))).ToListAsync();
                var result = new List<object>();
                foreach (Booking booking in bookings)
                {
                    int noOfDays = booking.CheckOutDate.Day - booking.CheckInDate.Day;
                    for (int i = 0; i <= noOfDays; i++) {


                        if (booking.ActualCheckOutDate != null)
                        {
                            result.Add(new
                            {
                                day = booking.CheckInDate.AddDays(i).Day,
                                content = new { Type = "default", Content = "Done", GuestFirstName = booking.Guest.FirstName, GuestLastName = booking.Guest.LastName }
                            });
                           
                        }
                        else if (booking.ActualCheckInDate != null)
                        {
                            result.Add(new
                            {
                                day = booking.CheckInDate.AddDays(i).Day,
                                content = new { Type = "processing", Content = "CheckIn", GuestFirstName = booking.Guest.FirstName , GuestLastName = booking.Guest.LastName }
                            });
                        }
                        else
                        {
                            result.Add(new
                            {
                                day = booking.CheckInDate.AddDays(i).Day,
                                content = new { Type = "warning", Content = "Booked", GuestFirstName = booking.Guest.FirstName, GuestLastName = booking.Guest.LastName }
                            });
                        }

                    }
                }
                return result;
            }
            else
            {
                return null;
            }
        }
    }
}
