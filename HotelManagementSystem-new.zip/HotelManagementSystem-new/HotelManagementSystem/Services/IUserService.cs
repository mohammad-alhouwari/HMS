﻿using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using Microsoft.AspNetCore.Identity;

namespace HotelManagementSystem.Services
{
    public interface IUserService
    {
        Task<IdentityResult> CreateUser(SignUpDTO dto);
        Task<SignInResult> Login(SignInDTO dto);
        Task<UserDTO> GetUserById(string id);
        Task<UserDTO> GetUserByUsername(string username);
        Task<List<UserDTO>> GetAllUsers(SearchUserDTO search);
        Task<IdentityResult> UpdateUser(UpdateUserDTO dto);
        Task<IdentityResult> DeleteUser(string id);
        Task<IList<string>> GetUserRoles(string username);
        Task<bool> UpdatePassword(UpdatePasswordDTO dto);
    }
}   