﻿using AutoMapper;
using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using HotelManagementSystem.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Runtime.CompilerServices;

namespace HotelManagementSystem.Services
{
    public class BookingService : IBookingService
    {
        private readonly IMapper mapper;
        private readonly IGeneric<Booking> generic;
        private readonly IRoomService roomService;
        private readonly HMSContext context;

        public BookingService(IMapper _mapper, IGeneric<Booking> _generic, IRoomService _roomService, HMSContext _context)
        {
            mapper = _mapper;
            generic = _generic;
            roomService = _roomService;
            context = _context;
        }

        public async Task<bool> Add(BookingDTO BookingDTO)
        {
            BookingDTO.IsPayed = false;
            Booking booking = mapper.Map<Booking>(BookingDTO);
            bool Check = await context.Bookings.AnyAsync(b =>b.RoomId == booking.RoomId &&((b.CheckInDate < booking.CheckOutDate && b.CheckOutDate > booking.CheckInDate) || (b.CheckInDate == booking.CheckOutDate || b.CheckOutDate == booking.CheckInDate)));
            if (!Check)
            {
                await generic.Add(booking);
                return true;
            }
            return false;
        }

        public async Task Update(BookingDTO BookingDTO)
        {
            Booking x = await generic.Load(BookingDTO.Id);

            if (x.ActualCheckInDate == null && x.ActualCheckOutDate == null)
            {
                Booking Booking = mapper.Map<Booking>(BookingDTO);
            await generic.Update(Booking);
            }
        }

        public async Task Delete(int id)
        {
            Booking x = await generic.Load(id);

            if (x.ActualCheckInDate == null && x.ActualCheckOutDate == null)
            {
                await generic.Delete(id);
            }
            
        }

        public async Task<BookingDTO> Load(int id)
        {
            return mapper.Map<BookingDTO>(await context.Bookings.Include(x => x.Room).Include(x => x.Guest).Where(x => x.Id == id).FirstOrDefaultAsync());
        }


        public async Task<List<BookingDTO>> LoadAll(SearchBookingDTO search)
        {
            IQueryable<Booking> query = context.Bookings.Include(b => b.Room).Include(b => b.Guest);

            if (!string.IsNullOrEmpty(search.RoomNumber))
            {
                List<int> roomIds = await context.Rooms.Where(r => r.RoomNumber.Contains(search.RoomNumber)).Select(r => r.Id).Distinct().ToListAsync();
                query = query.Where(b => roomIds.Contains(b.RoomId));
            }

            if (!string.IsNullOrEmpty(search.GuestName))
            {
                List<int> guestIds = await context.Guests.Where(g => g.FirstName.Contains(search.GuestName) || g.LastName.Contains(search.GuestName)).Select(g => g.Id).Distinct().ToListAsync();
                query = query.Where(b => guestIds.Contains(b.GuestId));
            }

            if (!string.IsNullOrEmpty(search.GuestPassportNumberOrId))
            {
                List<int> guestIds = await context.Guests.Where(g => g.PassportNumberOrId.Contains(search.GuestPassportNumberOrId)).Select(g => g.Id).Distinct().ToListAsync();
                query = query.Where(b => guestIds.Contains(b.GuestId));
            }

            if (search.CheckInDate.HasValue)
            {
                query = query.Where(b => b.CheckInDate <= search.CheckInDate.Value);
            }

            if (search.CheckOutDate.HasValue)
            {
                query = query.Where(b => b.CheckOutDate >= search.CheckOutDate.Value);
            }

            var result = await query.ToListAsync();
            return mapper.Map<List<BookingDTO>>(result);
        }




        public async Task<List<BookingDTO>> GetAllBookingForOneRoom(int id)
        {
            List<Booking> allBookingForOneRoom = await context.Bookings.Include(b => b.Room).Include(b => b.Guest).Where(b => b.RoomId == id).ToListAsync();
            return mapper.Map<List<BookingDTO>>(allBookingForOneRoom);
        }

        public async Task<List<BookingDTO>> GetAllNotPaidBookingForOneGuest(int id)
        {
            List<Booking> allBookingForOneGuest = await context.Bookings.Include(b => b.Room).Include(b => b.Guest).Where(b => b.GuestId == id && b.IsPayed == false).ToListAsync();
            return mapper.Map<List<BookingDTO>>(allBookingForOneGuest);
        }

        public async Task<string> CheckInBooking(int id)
        {
            Booking booking = await generic.Load(id);
            if (booking == null)
            {
                return "error while finding the booking";
            }
            else if (booking.IsPayed == false)
            {
                return "you need to pay first";
            }
            else if (booking.ActualCheckInDate != null)
            {
                return "error room is already CheckIn";
            }

            else if (booking.CheckInDate.Date > DateTime.Now.Date)
            {
                return "wait until "+ booking.CheckInDate.Date+ "to be able to Check-In";
            }    
            else if (booking.CheckOutDate.Date < DateTime.Now.Date)
            {
                return "you are too late the last possible time for Check-In was in "+ booking.CheckOutDate.Date;
            }
          
            else
            {
                booking.ActualCheckInDate= DateTime.Now.Date;
                await generic.Update(booking);
                await roomService.CheckInRoom(booking.RoomId);
                return "success";
            }
        }

        public async Task<string> CheckOutBooking(int id)
        {
            Booking booking = await generic.Load(id);

            if (booking == null)
            {
                return "error while finding the booking";
            }         
            else if ( booking.ActualCheckInDate != null && booking.CheckOutDate == null)
            {
                return "you need to Check-In first";
            }
            else if (booking.CheckInDate.Date > DateTime.Now.Date)
            {
                return "wait until " + booking.CheckInDate.Date + "to be able to Check-In";
            }
            
            else
            {
                booking.ActualCheckOutDate = DateTime.Now.Date;
                await roomService.CheckOutRoom(booking.RoomId);
                await generic.Update(booking);
                return "success";
            }
        }

    }
}
