﻿using HotelManagementSystem.DTOs;

namespace HotelManagementSystem.Services
{
    public interface IBookingService
    {
        Task<bool> Add(BookingDTO BookingDTO);
        Task Delete(int id);
        Task<BookingDTO> Load(int id);
        Task<List<BookingDTO>> LoadAll(SearchBookingDTO search);
        Task Update(BookingDTO BookingDTO);
        Task<List<BookingDTO>> GetAllBookingForOneRoom(int id);
        Task<List<BookingDTO>> GetAllNotPaidBookingForOneGuest(int id);

        Task<string> CheckInBooking(int id);
        Task<string> CheckOutBooking(int id);
    }
}