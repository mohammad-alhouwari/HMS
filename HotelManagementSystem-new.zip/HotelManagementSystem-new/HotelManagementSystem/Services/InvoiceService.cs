﻿using AutoMapper;
using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using HotelManagementSystem.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace HotelManagementSystem.Services
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IMapper mapper;
        private readonly IGeneric<Invoice> generic;
        private readonly HMSContext context;

        public InvoiceService(IMapper _mapper, IGeneric<Invoice> _generic, HMSContext _context)
        {
            mapper = _mapper;
            generic = _generic;
            context = _context;
        }

        public async Task Add(InvoiceDTO dto)
        {
            Booking booking = await context.Bookings.Include(b => b.Room).Where(b => b.Id == dto.BookingId).FirstOrDefaultAsync();
            dto.Duration = (Convert.ToDateTime(booking.CheckOutDate).Day - Convert.ToDateTime(booking.CheckInDate).Day + 1);
            dto.TotalAmount = dto.Duration * booking.Room.Price;
            Invoice Invoice = mapper.Map<Invoice>(dto);
            await generic.Add(Invoice);

            booking.IsPayed = true;
            context.Bookings.Attach(booking);
            context.Entry(booking).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await context.SaveChangesAsync();
        }
        public async Task Update(InvoiceDTO dto)
        {
            Invoice Invoice = mapper.Map<Invoice>(dto);
            await generic.Update(Invoice);
        }
        public async Task Delete(int id)
        {
            await generic.Delete(id);
        }
        public async Task<InvoiceDTO> Load(int id)
        {
            return mapper.Map<InvoiceDTO>(await generic.Load(id));
        }



        public async Task<List<InvoiceDTO>> LoadAll(SearchInvoiceDTO search)
        {
            IQueryable<Invoice> query = context.Invoices.Include(i => i.Booking).ThenInclude(b => b.Room).Include(i => i.Guest);
            if (search.InvoiceId.HasValue)
            {
                query = query.Where(i => i.Id == search.InvoiceId.Value);
            }
            if (search.Duration.HasValue)
            {
                query = query.Where(i => i.Duration == search.Duration.Value);
            }
            if (search.MinimumAmount.HasValue)
            {
                query = query.Where(i => i.TotalAmount >= search.MinimumAmount.Value);
            }
            if (search.MaximumAmount.HasValue)
            {
                query = query.Where(i => i.TotalAmount <= search.MaximumAmount.Value);
            }
            if (!string.IsNullOrEmpty(search.GuestName))
            {
                query = query.Where(i => i.Guest.FirstName.Contains(search.GuestName) || i.Guest.LastName.Contains(search.GuestName));
            }
            if (!string.IsNullOrEmpty(search.RoomNumber))
            {
                query = query.Where(i => i.Booking.Room.RoomNumber.Contains(search.RoomNumber));
            }

            List<Invoice> loadList = await query.ToListAsync();
            return mapper.Map<List<InvoiceDTO>>(loadList);
        }



    }
}
