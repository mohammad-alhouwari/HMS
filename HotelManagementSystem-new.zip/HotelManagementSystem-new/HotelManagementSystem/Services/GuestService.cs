﻿using AutoMapper;
using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using HotelManagementSystem.Generic;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Services
{
    public class GuestService : IGuestService
    {
        private readonly IMapper mapper;
        private readonly IGeneric<Guest> generic;
        private readonly HMSContext context;

        public GuestService(IMapper _mapper, IGeneric<Guest> _generic,HMSContext _context)
        {
            mapper = _mapper;
            generic = _generic;
            context = _context;
        }

        public async Task Add(GuestDTO GuestDTO)
        {
              
            Guest Guest = mapper.Map<Guest>(GuestDTO);
            await generic.Add(Guest);
        }
        public async Task Update(GuestDTO GuestDTO)
        {
            Guest Guest = mapper.Map<Guest>(GuestDTO);
            await generic.Update(Guest);
        }
        public async Task Delete(int id)
        {
            await generic.Delete(id);
        }
        public async Task<GuestDTO> Load(int id)
        {
            return mapper.Map<GuestDTO>(await generic.Load(id));
        }
        public async Task<List<GuestDTO>> LoadAll()
        {
            return mapper.Map<List<GuestDTO>>(await generic.LoadAll());
        }

        public async Task<List<GuestDTO>> LoadAllWithUnpaidBooking()
        {
            List<int> unpaidBooking = await context.Bookings.Where(b=>b.IsPayed == false).Select(b=>b.GuestId).ToListAsync();
            List<Guest> guests = await context.Guests.Where(g=> unpaidBooking.Contains(g.Id)).ToListAsync();
            return mapper.Map<List<GuestDTO>>(guests);
        }

    }
}
