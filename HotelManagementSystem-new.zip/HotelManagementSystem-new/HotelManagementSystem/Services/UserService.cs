﻿using AutoMapper;
using BookAppTest.Generic;
using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace HotelManagementSystem.Services
{
    public class UserService : IUserService
    {

        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;

        public UserService(UserManager<ApplicationUser> _userManager, SignInManager<ApplicationUser> _signInManager)
        {
            userManager = _userManager;
            signInManager = _signInManager;
        }

        public async Task<IdentityResult> CreateUser(SignUpDTO dto)
        {
            ApplicationUser newUser = new ApplicationUser
            {
                UserName = dto.Username,
                Email = dto.Email,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
            };

            var createUserResult = await userManager.CreateAsync(newUser, dto.Password);
            if (createUserResult.Succeeded)
            {
                var roleResult = await userManager.AddToRoleAsync(newUser, dto.RoleName);
                if (!roleResult.Succeeded)
                {
                    await userManager.DeleteAsync(newUser); 
                    return roleResult;
                }
            }
            return createUserResult;
        }

        public async Task<SignInResult> Login(SignInDTO dto)
        {
            return await signInManager.PasswordSignInAsync(dto.Username, dto.Password, false, false);
        }

        public async Task<UserDTO> GetUserById(string id)
        {
            ApplicationUser user = await userManager.FindByIdAsync(id);
            IList<string> roles = await GetUserRolesById(user.Id);

            UserDTO userDTO = new UserDTO()
            {
                Id = user.Id,
                UserName = user.UserName,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                RoleName = roles[0]
            };
            return userDTO;
        }

        public async Task<UserDTO> GetUserByUsername(string username)
        {
            ApplicationUser user = await userManager.FindByNameAsync(username);
            UserDTO userDTO = new UserDTO()
            {
                Id = user.Id,
                UserName = user.UserName,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
            };
            return userDTO;
        }


        public async Task<List<UserDTO>> GetAllUsers(SearchUserDTO search)
            {
            List<ApplicationUser> users = await userManager.Users.ToListAsync();

            if (!search.UserName.IsNullOrEmpty())
            {
                users = users.Where(r => r.UserName.Contains(search.UserName)).ToList();
            }        
            if (!search.Email.IsNullOrEmpty())
            {
                users = users.Where(r => r.Email.Contains(search.Email)).ToList();
            }        
            if (!search.Name.IsNullOrEmpty())
            {
                users = users.Where(g => g.FirstName.Contains(search.Name) || g.LastName.Contains(search.Name)).ToList();
            }

            List<UserDTO> usersDTO = new List<UserDTO>();

            foreach (var user in users)
            {
                IList<string> roles = await GetUserRolesById(user.Id);
                if (!search.Role.IsNullOrEmpty())
                {
                    if (roles[0] == search.Role)
                    {
                        usersDTO.Add(new UserDTO()
                        {
                            Id = user.Id,
                            UserName = user.UserName,
                            Email = user.Email,
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            RoleName = roles[0]
                        });
                    }                   
                }
                else
                {
                    usersDTO.Add(new UserDTO()
                    {
                        Id = user.Id,
                        UserName = user.UserName,
                        Email = user.Email,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        RoleName = roles[0]
                    });
                }


            }
            

            return usersDTO;
        }

        public async Task<IdentityResult> UpdateUser(UpdateUserDTO dto)
        {
            var user = await userManager.FindByIdAsync(dto.Id);
            if (user == null)
            {
                return IdentityResult.Failed(new IdentityError { Description = "User not found" });
            }
            user.Email = dto.Email;
            user.FirstName = dto.FirstName;
            user.LastName = dto.LastName;
            user.UserName = dto.Username;

            IList<string> roles = await GetUserRolesById(user.Id);
            if (roles[0] != dto.RoleName)
            {
                await userManager.RemoveFromRoleAsync(user, roles[0]);
                await userManager.AddToRoleAsync(user, dto.RoleName);
            }

            return await userManager.UpdateAsync(user);
        }

        public async Task<IdentityResult> DeleteUser(string id)
        {
            var user = await userManager.FindByIdAsync(id);

            if (user == null)
            {
                return IdentityResult.Failed(new IdentityError { Description = "User not found" });
            }
            var userRoles = await GetUserRoles(user.UserName);
            if (userRoles.Contains("Admin"))
            {
                return IdentityResult.Failed(new IdentityError { Description = "Cant Delete Admine" });
            }
            return await userManager.DeleteAsync(user);
        }

        public async Task<IList<string>> GetUserRoles(string username)
        {
            var user = await userManager.FindByNameAsync(username);
            if (user == null)
            {
                return new List<string>();
            }
            return await userManager.GetRolesAsync(user);
        }

        public async Task<IList<string>> GetUserRolesById(string id)
        {
            var user = await userManager.FindByIdAsync(id);
            return await userManager.GetRolesAsync(user);
        }


        public async Task<bool> UpdatePassword(UpdatePasswordDTO dto)
        {
            var user = await userManager.FindByIdAsync(dto.UserId);
            if (user == null)
            {
                throw new Exception("User not found");
            }

            var result = await userManager.ChangePasswordAsync(user, dto.OldPassword, dto.NewPassword);
            if (!result.Succeeded)
            {
                throw new Exception("Password update failed: " + string.Join(", ", result.Errors));
            }

            return true;
        }
    }
}
