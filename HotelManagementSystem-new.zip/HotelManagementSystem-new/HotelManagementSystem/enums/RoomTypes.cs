﻿namespace HotelManagementSystem.Enums
{
    public enum RoomTypes
    {
        Single,
        Double,
        Suite
    }
}
