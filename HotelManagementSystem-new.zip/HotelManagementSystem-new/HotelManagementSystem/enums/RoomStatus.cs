﻿namespace HotelManagementSystem.Enums
{
    public enum RoomStatus
    {
        Available,
        Occupied
    }
}
