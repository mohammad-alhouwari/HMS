﻿using HotelManagementSystem.DTOs;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    
    public class RoleController : ControllerBase
    {
        private readonly IRoleService roleService;

        public RoleController(IRoleService _roleService)
        {
            roleService = _roleService;
        }


        [HttpGet]
        [Route("{id}")]

        public async Task<IActionResult> GetRoleById(string id)
        {
            var role = await roleService.GetRoleById(id);
            if (role == null)
            {
                return NotFound("Role not found.");
            }
            return Ok(role);
        }

        [HttpGet]
        [Route("AllRoles")]
        [AllowAnonymous]
        public async Task<IActionResult> GetAllRoles()
        {
            var roles = await roleService.GetAllRoles();
            return Ok(roles);
        }
        [HttpGet]
        [Route("UsersInRole/{roleName}")]
        public async Task<IActionResult> GetUsersInRole(string roleName)
        {
            var users = await roleService.GetUsersInRole(roleName);
            if (users == null || !users.Any())
            {
                return Ok(new { message = "No users found in this role." });
            }
            return Ok(users);
        }
        [HttpPost]
        [Route("AddUserToRole")]
        public async Task<IActionResult> AddUserToRole(UserToRoleDTO dto)
        {
            var success = await roleService.AddUserToRole(dto.UserId, dto.RoleName);
            if (!success)
            {
                return BadRequest("Failed to add user to role. User or role may not exist.");
            }
            return Ok(new { message = "User added to role successfully." });

        }

        [HttpDelete]
        [Route("RemoveUserFromRole")]
        public async Task<IActionResult> RemoveUserFromRole(string userId, string roleName)
        {
            var success = await roleService.RemoveUserFromRole(userId, roleName);
            if (!success)
            {
                return BadRequest("Failed to remove user from role. User or role may not exist.");
            }
            return Ok(new { message = "User removed from role successfully." });
        }

        [HttpGet]
        [Route("UsersNotInRole/{roleName}")]
        public async Task<IActionResult> GetUsersNotInRole(string roleName)
        {
            List<UserDTO> users = await roleService.GetUsersNotInRole(roleName);
            if (users == null || !users.Any())
            {
                return Ok(new { message = "No users found outside this role." });
            }
            return Ok(users);
        }

    }
}
