﻿using HotelManagementSystem.DTOs;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BookingController : ControllerBase
    {
        private readonly IBookingService service;

        public BookingController(IBookingService _service)
        {
            service = _service;
        }

        [HttpPost]
        public async Task<IActionResult> Add(BookingDTO dto)
        {
            try
            {
                await service.Add(dto);
                return Ok(new { message = "Booking added successfuly"});
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpPut]
        public async Task<IActionResult> Update(BookingDTO dto)
        {
            try
            {
                await service.Update(dto);
                return Ok(new { message = "Booking Updated successfuly" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await service.Delete(id);
                return Ok(new { message = "Booking Deleted successfuly" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Load(int id)
        {
            try
            {
                return Ok(await service.Load(id));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("LoadAll")]

        public async Task<IActionResult> LoadAll([FromQuery] SearchBookingDTO search)
        {
            try
            {
                return Ok(await service.LoadAll(search));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }



        [HttpGet]
        [Route("GetAllBookingForOneRoom")]
        public async Task<IActionResult> GetAllBookingForOneRoom(int id)
        {
            try
            {
                return Ok(await service.GetAllBookingForOneRoom(id));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }      
        [HttpGet]
        [Route("GetAllNotPaidBookingForOneGuest")]
        public async Task<IActionResult> GetAllNotPaidBookingForOneGuest(int id)
        {
            try
            {
                return Ok(await service.GetAllNotPaidBookingForOneGuest(id));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        [Route("CheckIn/{id}")]
        public async Task<IActionResult> CheckIn(int id)
        {
            try
            {
                string result =  await service.CheckInBooking(id);
                if (result == "success")
                {
                return Ok(new { message = "CheckIn successfuly Now the Room Occupied" });
                }
                else
                {
                    return BadRequest(new { error = result });
                }

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        [Route("CheckOut/{id}")]
        public async Task<IActionResult> CheckOut(int id)
        {
                try
                {
                string result = await service.CheckOutBooking(id);
                if (result == "success")
                {               
                    return Ok(new { message = "CheckOut successfuly Now the Room Available" });
                }
                else
                {
                    return BadRequest(new { error = result });
                }
                }
                catch (Exception ex)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
                }
            }

    }
}
