﻿using HotelManagementSystem.data;
using HotelManagementSystem.DTOs;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,Front desk")]
    public class RoomController : ControllerBase
    {
        private readonly IRoomService service;

        public RoomController(IRoomService _service)
        {
            service = _service;
        }

        [HttpPost]
        public async Task<IActionResult> Add(RoomDTO dto)
        {
            try
            {
                await service.Add(dto);
                return Ok(new { message = "Room added successfully" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpPut]
        public async Task<IActionResult> Update(RoomDTO dto)
        {
            try
            {
                await service.Update(dto);
                return Ok(new { message = "Room updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await service.Delete(id);
                return Ok(new { message = "Room Deleted successfully" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Load(int id)
        {
            try
            {
                return Ok(await service.Load(id));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("LoadAll")]

        public async Task<IActionResult> LoadAll([FromQuery]SearchRoomDTO? search )
        {
            try
            {
                return Ok(await service.LoadAll(search));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("LoadAllAvailable")]
        public async Task<IActionResult> LoadAllAvailable()
        {
            try
            {
                return Ok(await service.LoadAllAvailable());
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }     
        [HttpGet]
        [Route("LoadAllAvailableRoomsForBooking")]
        public async Task<IActionResult> LoadAllAvailableRoomsForBooking(DateTime checkInDate , DateTime checkOutDate, int? currentRoomId = null)
        {
            try
            {
                return Ok(await service.LoadAllAvailableRoomsForBooking(checkInDate, checkOutDate, currentRoomId));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpGet]
        [Route("GetAllRoomBookingsInMonth")]
        [AllowAnonymous]
        public async Task<List<object>> GetAllRoomBookingsInMonth(DateTime date, int roomId)
        {
            return await service.GetAllRoomBookingsInMonth(date, roomId);
        }
        [HttpGet("GetRoomTypes")]
        [AllowAnonymous]
        public IActionResult GetRoomTypes()
        {
            var roomTypes = service.GetRoomTypes();
            return Ok(roomTypes);
        }
    }
}
