﻿using HotelManagementSystem.DTOs;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class GuestController : ControllerBase
    {
        private readonly IGuestService service;

        public GuestController(IGuestService _service)
        {
            service = _service;
        }

        [HttpPost]
        public async Task<IActionResult> Add(GuestDTO dto)
        {
            try
            {
                await service.Add(dto);
                return Ok(new { message = "Guest added successfuly" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpPut]
        public async Task<IActionResult> Update(GuestDTO dto)
        {
            try
            {
                await service.Update(dto);
                return Ok(new { message = "Guest Updated successfuly" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await service.Delete(id);
                return Ok(new { message = "Guest Deleted successfuly" });

            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> Load(int id)
        {
            try
            {
                return Ok(await service.Load(id));
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("LoadAll")]
        public async Task<IActionResult> LoadAll()
        {
            try
            {
                return Ok(await service.LoadAll());
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }   
        [HttpGet]
        [Route("LoadAllWithUnpaidBooking")]
        public async Task<IActionResult> LoadAllWithUnpaidBooking()
        {
            try
            {
                return Ok(await service.LoadAllWithUnpaidBooking());
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }


    }
}
