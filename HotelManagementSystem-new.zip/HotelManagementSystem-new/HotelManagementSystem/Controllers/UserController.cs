﻿using HotelManagementSystem.DTOs;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;

        public UserController(IUserService _userService)
        {
            userService = _userService;
        }

        [HttpPost]
        [Route("SignUp")]
        public async Task<IActionResult> SignUp([FromBody] SignUpDTO signUpDTO)
        {
            try
            {
                var result = await userService.CreateUser(signUpDTO);
                if (result.Succeeded)
                {
                    //return StatusCode((int)HttpStatusCode.OK, "User added successfully");
                    return Ok(new { message = "User added successfully" });

                }
                else
                {
                    return StatusCode((int)HttpStatusCode.BadRequest, result.Errors);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        [Route("SignIn")]
        [AllowAnonymous]
        public async Task<IActionResult> SignIn([FromBody] SignInDTO signInDTO)
        {
            var result = await userService.Login(signInDTO);
            if (result.Succeeded)
            {
                List<Claim> claims = new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, signInDTO.Username),
                    new Claim("uniquValue", Guid.NewGuid().ToString())
                };
                var UserRoles = await userService.GetUserRoles(signInDTO.Username);
                foreach (var role in UserRoles)
                {
                    claims.Add(new Claim(ClaimTypes.Role, role));
                }
                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("2ffb4a02176f91b7dac44d863f9eccfcd48349236031678034f32c2f6bf47b6c3b439e0657a094134f2dd750602c2adb7a53d485c3553859abc526a1445936820752349361375a834e27dc814880e6c6d3ecfff80803a55cd9d7cdfc5cd30867badedca1b02ee0399a0c7d949f7901370b4667252baab4cafc6e4e33f1dd5905"));

                var token = new JwtSecurityToken(
                            issuer: "http://localhost",
                            audience: "User",
                            expires: DateTime.Now.AddDays(15),
                            claims: claims,
                            signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                            );
                return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token), Role = UserRoles[0] });
            }
            else
            {
                return Unauthorized();
            }
        }

        [HttpGet]
        [Route("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetUserById(string id)
        {
            UserDTO user = await userService.GetUserById(id);
            if (user == null)
            {
                return NotFound("User not found");
            }
            return Ok(user);
        }  
        [HttpGet]
        [Route("GetUserByUsername/{username}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetUserByUsername(string username)
        {
            UserDTO user = await userService.GetUserByUsername(username);
            if (user == null)
            {
                return NotFound("User not found");
            }
            return Ok(user);
        }

        [HttpGet]
        [Route("LoadAll")]
        [Authorize]
        public async Task<IActionResult> GetAllUsers([FromQuery] SearchUserDTO search)
        {
            var users = await userService.GetAllUsers(search);
            return Ok(users);
        }

        [HttpPut]
        [Authorize]
        public async Task<IActionResult> UpdateUser(UpdateUserDTO dto)
        {
            var result = await userService.UpdateUser(dto);
            if (result.Succeeded)
            {
                return Ok(new { message = "User updated successfully" });
            }
            return BadRequest(result.Errors);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteUser(string id)
        {
            var result = await userService.DeleteUser(id);
            if (result.Succeeded)
            {
                return Ok(new { message = "User deleted successfully" });
            }
            return BadRequest(result.Errors);
        }
        
        [HttpGet]
        [Route("GetUserRoles")]
        [AllowAnonymous]
        public async Task<IActionResult> GetUserRoles(string username)
        {
           return Ok(await userService.GetUserRoles(username));
        }

        [HttpPut]
        [Route("UpdatePassword")]

        public async Task<IActionResult> UpdatePassword(UpdatePasswordDTO dto)
        {
            if (dto == null || string.IsNullOrEmpty(dto.OldPassword) || string.IsNullOrEmpty(dto.NewPassword))
            {
                return BadRequest("Invalid password data");
            }

            try
            {
                await userService.UpdatePassword(dto);
                return Ok(new { message = "Password updated successfully" });

            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
