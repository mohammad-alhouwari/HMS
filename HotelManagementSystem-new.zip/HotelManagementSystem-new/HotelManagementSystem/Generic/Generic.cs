﻿using HotelManagementSystem.data;
using HotelManagementSystem.Generic;
using Microsoft.EntityFrameworkCore;

namespace BookAppTest.Generic
{
    public class Generic<T> : IGeneric<T> where T : class
    {
        private readonly HMSContext context;

        public Generic(HMSContext _context)
        {
            context = _context;
        }

        public async Task Add(T entity)
        {
            await context.Set<T>().AddAsync(entity);
            await context.SaveChangesAsync();
        }
        public async Task Update(T entity)
        {
            context.Set<T>().Attach(entity);
            context.Entry(entity).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await context.SaveChangesAsync();

        }
        public async Task Delete(int id)
        {
            T t = await context.Set<T>().FindAsync(id);
            context.Remove(t);
            await context.SaveChangesAsync();
        }
        public async Task<T> Load(int id)
        {
            return await context.Set<T>().FindAsync(id);
        }

        public async Task<List<T>> LoadAll()
        {
            return await context.Set<T>().ToListAsync();
        }


    }
}
