﻿
namespace HotelManagementSystem.Generic
{
    public interface IGeneric<T> where T : class
    {
        Task Add(T entity);
        Task Delete(int id);
        Task<T> Load(int id);
        Task<List<T>> LoadAll();
        Task Update(T entity);
    }
}