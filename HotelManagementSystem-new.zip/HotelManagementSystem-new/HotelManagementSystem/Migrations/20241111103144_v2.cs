﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HotelManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class v2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsComplete",
                table: "Bookings");

            migrationBuilder.AddColumn<DateTime>(
                name: "ActualCheckInDate",
                table: "Bookings",
                type: "date",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ActualCheckOutDate",
                table: "Bookings",
                type: "date",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1a2b3c4d-5e6f-7890-abcd-1234567890ab",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "5294cce1-c0ab-48ed-b9c5-443b1260b44c", "AQAAAAIAAYagAAAAEAqnH2VqVXNIeX7p7ZXB2XMUya+vf6Vn7swTTqODa3eFSGefeME+2wJrJULV+zqI/A==", "c5121055-ad2a-4bd8-99cc-3d0844c562f8" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ActualCheckInDate",
                table: "Bookings");

            migrationBuilder.DropColumn(
                name: "ActualCheckOutDate",
                table: "Bookings");

            migrationBuilder.AddColumn<bool>(
                name: "IsComplete",
                table: "Bookings",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1a2b3c4d-5e6f-7890-abcd-1234567890ab",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "9070d25e-39b6-43fa-af79-56518dd20d3d", "AQAAAAIAAYagAAAAEC3dCZO04lD6wGRZThaM4ebPqaJPMxcyRl9a2XsIAfFgm+aNZowG8p2OK4Ir1geDxQ==", "4c60e476-bf54-4424-b71c-af4b0eb67e44" });
        }
    }
}
