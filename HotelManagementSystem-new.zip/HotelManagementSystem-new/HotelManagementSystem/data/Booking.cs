﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.data
{
    [Table("Bookings")]

    public class Booking 
    {
        [Key]
        public int Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime CheckInDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime CheckOutDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ActualCheckInDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ActualCheckOutDate { get; set; }

        [ForeignKey(nameof(Guest))]
        public int GuestId { get; set; }
        [ForeignKey(nameof(Room))]
        public int RoomId { get; set; }
        public bool IsPayed { get; set; }
        public Guest Guest { get; set; }
        public Room Room { get; set; }
        public Invoice Invoice { get; set; }
    }
}
