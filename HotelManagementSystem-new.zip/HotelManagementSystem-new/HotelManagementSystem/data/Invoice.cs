﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.data
{
    [Table("Invoices")]
    public class Invoice
    {
        [Key]
        public int Id { get; set; }
        public int Duration { get; set; }
        public double TotalAmount { get; set; }
        [StringLength(500)]
        public string Notes { get; set; }


        [ForeignKey(nameof(Guest))]
        public int GuestId { get; set; }
        [DeleteBehavior(DeleteBehavior.NoAction)]
        public Guest Guest { get; set; }


        [ForeignKey(nameof(Booking))]
        public int BookingId { get; set; }
        [DeleteBehavior(DeleteBehavior.NoAction)]
        public Booking Booking { get; set; }
    }
}
