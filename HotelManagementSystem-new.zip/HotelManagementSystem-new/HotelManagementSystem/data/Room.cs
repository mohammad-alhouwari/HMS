﻿using HotelManagementSystem.Enums;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.data
{
    [Table("Rooms")]
    [Index(nameof(RoomNumber), IsUnique = true)]
    public class Room 
    {
        [Key]
        public int Id { get; set; }
        public string RoomNumber { get; set; }
        public int Capacity { get; set; }
        public double Price { get; set; }
        public string RoomStatus { get; set; }
        public string RoomType { get; set; }

        //public RoomStatus RoomStatus { get; set; }
        //public RoomTypes RoomType { get; set; }
    }
}
